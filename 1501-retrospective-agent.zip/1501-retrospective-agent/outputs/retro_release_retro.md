# 结算服务发布复盘

> 生成器：ClawHunt #1501 复盘 Agent（确定性流水线，不联网、不调用任何模型 API）
> 场景：`release_retro`｜数据窗口：2026-03-09T00:00:00Z ~ 2026-03-16T00:00:00Z
> 事件总数：32｜采纳证据：16｜拒绝证据（非白名单来源）：1

## 1. 事实（Fact）

**F-01**（规则 `R-CO-DEPLOY-FAIL`）：窗口内共 5 次部署，其中失败 3 次，失败率 0.6（阈值 0.3）。
  证据：`EVT-d294d67c`@2026-03-09T10:00:00Z、`EVT-a98a79f5`@2026-03-09T14:00:00Z、`EVT-cc97f54e`@2026-03-10T09:30:00Z、`EVT-b74a4843`@2026-03-11T11:00:00Z、`EVT-e90e8f96`@2026-03-13T10:20:00Z

**F-02**（规则 `R-CO-REVIEW-LAG`）：窗口内变更评审平均等待 22 小时（阈值 12 小时）。
  证据：`EVT-20bb8ab3`@2026-03-12T10:15:00Z、`EVT-0786d6a2`@2026-03-13T15:30:00Z

## 2. 证据引用（Evidence Index）

每条证据都带证据 ID（事件 ID）与时间戳，可回溯到来源系统与来源单据。

| 证据 ID | 时间戳 | 来源类型 | 来源单据 | 摘要 |
|---|---|---|---|---|
| `EVT-d294d67c` | 2026-03-09T10:00:00Z | deploy_pipeline | `REF-1bc0594a` | deploy/success; service=checkout |
| `EVT-a98a79f5` | 2026-03-09T14:00:00Z | deploy_pipeline | `REF-2864ed39` | deploy/failure; service=checkout |
| `EVT-0842a91b` | 2026-03-09T14:20:00Z | deploy_pipeline | `REF-2864ed39` | rollback/success; service=checkout |
| `EVT-cc97f54e` | 2026-03-10T09:30:00Z | deploy_pipeline | `REF-dd536082` | deploy/failure; service=checkout |
| `EVT-064445d9` | 2026-03-10T09:50:00Z | deploy_pipeline | `REF-dd536082` | rollback/success; service=checkout |
| `EVT-b74a4843` | 2026-03-11T11:00:00Z | deploy_pipeline | `REF-a6502280` | deploy/success; service=checkout |
| `EVT-20bb8ab3` | 2026-03-12T10:15:00Z | ticket_system | `REF-2237804a` | review_requested/pending; service=checkout; wait_hours=26 |
| `EVT-c4234bf2` | 2026-03-12T16:00:00Z | ticket_system | `REF-2237804a` | review_completed/success; service=checkout; wait_hours=26 |
| `EVT-e90e8f96` | 2026-03-13T10:20:00Z | deploy_pipeline | `REF-b2159ca6` | deploy/failure; service=checkout |
| `EVT-c21ed86e` | 2026-03-13T10:40:00Z | deploy_pipeline | `REF-b2159ca6` | rollback/success; service=checkout |
| `EVT-0786d6a2` | 2026-03-13T15:30:00Z | ticket_system | `REF-500c40ed` | review_requested/pending; service=checkout; wait_hours=18 |
| `EVT-8eacb55f` | 2026-03-14T09:00:00Z | ticket_system | `REF-500c40ed` | review_completed/success; service=checkout; wait_hours=18 |
| `EVT-041c0539` | 2026-03-15T09:10:00Z | incident_log | `REF-3c2d28ab` | incident_opened/none; service=checkout; severity=medium; time_to_detect_minutes=12 |
| `EVT-78235972` | 2026-03-15T09:20:00Z | ticket_system | `REF-c2727ed5` | ticket_opened/pending; service=checkout |
| `EVT-8431c6e7` | 2026-03-15T12:00:00Z | incident_log | `REF-3c2d28ab` | incident_resolved/success; service=checkout; duration_minutes=170 |
| `EVT-1c957943` | 2026-03-15T18:00:00Z | survey | `REF-42736e97` | postmortem_published/success; service=checkout; rating=4 |

## 3. 结论（Conclusion）

每条结论强制挂 >= 1 条证据 ID + 时间戳，否则在生成阶段直接报错、不产出该结论。

**C-01**（置信度 0.75）：部署失败率 0.6 高于阈值 0.3，发布流水线的稳定性需要治理。
  依据事实 `F-01`；证据 `EVT-d294d67c`@2026-03-09T10:00:00Z、`EVT-a98a79f5`@2026-03-09T14:00:00Z、`EVT-cc97f54e`@2026-03-10T09:30:00Z、`EVT-b74a4843`@2026-03-11T11:00:00Z、`EVT-e90e8f96`@2026-03-13T10:20:00Z

**C-02**（置信度 0.60）：变更评审平均等待 22 小时高于阈值 12 小时，评审环节成为发布瓶颈。
  依据事实 `F-02`；证据 `EVT-20bb8ab3`@2026-03-12T10:15:00Z、`EVT-0786d6a2`@2026-03-13T15:30:00Z

## 4. 改进项（Improvement）

每条改进项都必须回溯到至少一条结论；结论的证据即改进项的证据。

**A-01**［high］为结算服务发布流水线增加发布前校验与灰度门禁，降低失败率。
  负责角色：release_manager；回溯结论：C-01；由结论 C-01 支撑（该结论挂 5 条证据）

**A-02**［medium］为结算服务变更建立评审人轮值机制并设置等待时长提醒。
  负责角色：release_manager；回溯结论：C-02；由结论 C-02 支撑（该结论挂 2 条证据）

## 5. 被拒绝的证据（非白名单来源）

下列来源不在证据白名单内，已按规则拒绝，且未进入任何事实或结论。

| 证据 ID | 时间戳 | 来源类型 | 拒绝原因 |
|---|---|---|---|
| `EVT-f5c7073c` | 2026-03-14T13:00:00Z | manager_note | 来源类型 'manager_note' 不在证据白名单内（允许：chat_ops, deploy_pipeline, incident_log, survey, ticket_system） |

## 6. 依据链（可溯源）

事实 → 证据引用 → 结论 → 改进项 的完整回溯链如下。

- A-01 → C-01 → F-01 → `EVT-d294d67c`@2026-03-09T10:00:00Z、`EVT-a98a79f5`@2026-03-09T14:00:00Z、`EVT-cc97f54e`@2026-03-10T09:30:00Z、`EVT-b74a4843`@2026-03-11T11:00:00Z、`EVT-e90e8f96`@2026-03-13T10:20:00Z
- A-02 → C-02 → F-02 → `EVT-20bb8ab3`@2026-03-12T10:15:00Z、`EVT-0786d6a2`@2026-03-13T15:30:00Z
